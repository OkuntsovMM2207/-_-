using ConsoleAppTesting;
namespace ConsoleInputOutputHandler
{
    [TestClass]
    public class ConsoleAppShould
    {
        [TestMethod]
        public void ReturnEmptyStringConst()
        {
            //Arrange
            string input = "";
            string expectedOutput = "�� ����� ������ ������" +
                Environment.NewLine;
            StringWriter output = new StringWriter();
            Console.SetIn(new StringReader(input));
            Console.SetOut(output);
            //Act
            ConsoleAppTesting.Program.Main(new string[] { });
            //Assert
            Assert.AreEqual(expectedOutput, output.ToString());
        }
        [TestMethod]
        public void ReturnStringItselfWhenNotEmpty()
        {
            //Arrange
            string input = "abc" + Environment.NewLine + "abc";
            string expectedOutput = input + Environment.NewLine;
            StringWriter output = new StringWriter();
            Console.SetIn(new StringReader(input));
            Console.SetOut(output);
            //Act
            ConsoleAppTesting.Program.Main(new string[] { });
            //Assert
            Assert.AreEqual(expectedOutput, output.ToString());
        }
    }
}